package dao;

import pojos.Team;
import org.hibernate.*;
import static utils.HibernateUtils.getFactory;;
public class TeamDaoImpl implements TeamDao {

	@Override
	public String addTeamDetails(Team newTeam) {
		
		//1.open hibernate session from sf
		
		Session session = getFactory().openSession();
		
		//2.begin a transaction
		
		Transaction tx = session.beginTransaction();
		
		try {
			//save the team details
			session.save(newTeam);
			
			//end of try--> Success
			tx.commit();
		}
		catch (RuntimeException e) {
			
			//rollback the transaction and throw the exception
			if(tx!=null)
				tx.rollback();
			throw e;
		}
		finally {
			//close the session
			if(session!=null)
				session.close();
		}
		return "Added new team with id: "+newTeam.getTeamId();
	}
	

}
