package tester;
import org.hibernate.*;

import dao.TeamDao;
import dao.TeamDaoImpl;
import pojos.Team;

import static utils.HibernateUtils.getFactory;

import java.util.Scanner;

public class AddNewTeam {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try(Scanner sc = new Scanner(System.in);SessionFactory sf = getFactory())
		
		{
			System.out.println("Hibernate Booted successfully..."+sf);
			
			//create dao instance and call method
			TeamDao dao = new TeamDaoImpl();
			
			//name, abbreviation, owner, maxAge, minBattingAvg, minWicketsTaken
			
			System.out.println("Enter new team: name, abbreviation, owner, maxAge, minBattingAvg, minWicketsTaken--->");
			Team newTeam = new Team(sc.next(),sc.next(),sc.next(),sc.nextInt(),sc.nextDouble(),sc.nextInt());
			
			System.out.println(dao.addTeamDetails(newTeam));
		}
		//sf.close ---> DBCP(DB conn pool) closed
		catch (Exception e) {
			e.printStackTrace();
		}
		
	}

}
