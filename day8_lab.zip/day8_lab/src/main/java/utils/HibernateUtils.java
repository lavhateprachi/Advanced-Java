package utils;

import org.hibernate.*;
import org.hibernate.cfg.Configuration;

//create singleton immutable inherently thread safe, time consuming session factory
public class HibernateUtils {
	
	private static SessionFactory factory; //null
	
	static {
		System.out.println("inside static block");
		
		factory=new Configuration(). //EMPTY
				configure() //Populated 
				.buildSessionFactory();
	}

	public static SessionFactory getFactory() {
		return factory;
	}
	

}
