package pojos;
import javax.persistence.*;

/*
 * team_id | name| abbrevation | owner  | max_age | batting_avg | wickets_taken
 */
@Entity //class level annotation,to tell hibernate ,following is the entity class,whose life cycle to be managed by hibernate

@Table(name = "team_table")
public class Team {
	
	@Id //field level mandatory annotation ,to place PK constraint for auto id generation
	
	@GeneratedValue(strategy = GenerationType.IDENTITY)//for auto id generation, using auto increment constraint
	
	@Column(name = "Team_Id")
	private Integer teamId;//PK //as per Founder( Gavin King),till hiberanate 5, use @Id property explicitly serializable
	private String name;
	private String abbreviation;
	private String owner;
	@Column(name = "Max_Age")
	private int maxAge;
	
	@Column(name = "Min_Batting_avg")
	private double minBattingAvg;
	
	private int minWicketsTaken;
	public Team() {
		// TODO Auto-generated constructor stub
	}
	
	
	public Team(String name, String abbreviation, String owner, int maxAge, double minBattingAvg,int minWicketsTaken) {
		super();
		this.name = name;
		this.abbreviation = abbreviation;
		this.owner = owner;
		this.maxAge = maxAge;
		this.minBattingAvg = minBattingAvg;
		this.minWicketsTaken = minWicketsTaken;
	}


	public Integer getTeamId() {
		return teamId;
	}
	public void setTeamId(Integer teamId) {
		this.teamId = teamId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAbbreviation() {
		return abbreviation;
	}
	public void setAbbreviation(String abbreviation) {
		this.abbreviation = abbreviation;
	}
	public String getOwner() {
		return owner;
	}
	public void setOwner(String owner) {
		this.owner = owner;
	}
	public int getMaxAge() {
		return maxAge;
	}
	public void setMaxAge(int maxAge) {
		this.maxAge = maxAge;
	}
	public double getMinBattingAvg() {
		return minBattingAvg;
	}
	public void setMinBattingAvg(double minBattingAvg) {
		this.minBattingAvg = minBattingAvg;
	}
	public int getMinWicketsTaken() {
		return minWicketsTaken;
	}
	public void setMinWicketsTaken(int minWicketsTaken) {
		this.minWicketsTaken = minWicketsTaken;
	}
	@Override
	public String toString() {
		return "Team [teamId=" + teamId + ", name=" + name + ", abbreviation=" + abbreviation + ", owner=" + owner
				+ ", maxAge=" + maxAge + ", minBattingAvg=" + minBattingAvg + ", minWicketsTaken=" + minWicketsTaken
				+ "]";
	}
	
}
