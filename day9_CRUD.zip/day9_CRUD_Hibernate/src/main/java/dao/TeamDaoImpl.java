package dao;

import pojos.Team;
import static utils.HibernateUtils.getSf;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;;

public class TeamDaoImpl implements TeamDao{

	@Override
	public String addNewTeamDetails(Team newTeam) {
		
		Session session = getSf().getCurrentSession();
		Transaction tx = session.beginTransaction();
		try 
		{
			session.save(newTeam);
			tx.commit();
		}
		catch(RuntimeException e)
		{
			if(tx!=null)
			{
				tx.rollback();
			}
			throw e;
		}
		return "Team Details Inserted Successfully: "+newTeam.getName();
	}

	@Override
	public List<Team> displayAllTeamDetails() {
		Session session = getSf().getCurrentSession();
		
		Transaction tx = session.beginTransaction();
		String jpql = "select e from Team e";
		List<Team> list = null;
		try 
		
		{
			list=session.createQuery(jpql, Team.class).getResultList();	
			tx.commit();
		}
		catch(RuntimeException e)
		{
			if(tx!=null)
			{
				tx.rollback();
			}
			throw e;
		}
		return list;
	}

	@Override
	public Team displaySpecificDetails(int id) {
		Session session = getSf().getCurrentSession();
		
		Transaction tx = session.beginTransaction();
		Team team = null;
		String jpql = "select t from Team t where t.teamId=:id";
		
		try {
			team = session.createQuery(jpql, Team.class).setParameter("id",id).getSingleResult();
			tx.commit();
			
		}catch(RuntimeException e)
		{
			if(tx!=null)
			{
				tx.rollback();
			}
			throw e;
		}
		return team;
		
	}
	
}
