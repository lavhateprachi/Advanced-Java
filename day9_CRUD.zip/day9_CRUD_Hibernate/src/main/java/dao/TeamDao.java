package dao;

import java.util.List;

import pojos.Team;

public interface TeamDao {
	
	String addNewTeamDetails(Team newTeam);
	
	List<Team> displayAllTeamDetails();
	
	Team displaySpecificDetails(int id);

}
