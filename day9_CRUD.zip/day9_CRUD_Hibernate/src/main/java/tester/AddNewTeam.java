package tester;

import utils.HibernateUtils;

import java.util.Scanner;

import org.hibernate.SessionFactory;

import dao.TeamDao;
import dao.TeamDaoImpl;
import pojos.Team;

public class AddNewTeam {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		TeamDao dao = new TeamDaoImpl();
		
		try(SessionFactory sf = HibernateUtils.getSf(); Scanner sc = new Scanner(System.in))
		{
	
			//String name, String abbreviation, String owner, int maxAge, double minBattingAvg,int minWicketsTaken
			System.out.println("Enter Team Details:  name, abbreviation, maxAge, minBattingAvg, minWicketsTaken");
			
			Team newTeam = new Team(sc.next(), sc.next(), sc.nextInt(), sc.nextDouble(), sc.nextInt());
			System.out.println("Team Details: "+dao.addNewTeamDetails(newTeam));
		}
		catch(RuntimeException e)
		{
			e.printStackTrace();
		}

	}

}
