package tester;

import java.util.List;
import java.util.Scanner;

import org.hibernate.SessionFactory;

import dao.TeamDao;
import dao.TeamDaoImpl;
import pojos.Team;
import utils.HibernateUtils;

public class displaySpecificDetails {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try(Scanner sc = new Scanner(System.in);SessionFactory SF = HibernateUtils.getSf())
		{
			TeamDao dao = new TeamDaoImpl();
			System.out.println("Display Team Details Using Team_Id: ");
			
			Team team = dao.displaySpecificDetails(sc.nextInt());
			
			System.out.println("Team Details: "+team);
			
		}
	}

}
