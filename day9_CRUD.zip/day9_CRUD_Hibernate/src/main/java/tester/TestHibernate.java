package tester;

import org.hibernate.SessionFactory;
import utils.HibernateUtils;
public class TestHibernate {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try(SessionFactory sf = HibernateUtils.getSf())
		{
			System.out.println("Hibernate Tested Successfully...");
		}
		catch(RuntimeException e)
		{
			e.printStackTrace();
		}

	}

}
