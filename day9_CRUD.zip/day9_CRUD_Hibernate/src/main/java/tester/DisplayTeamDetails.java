package tester;

import java.util.List;

import org.hibernate.SessionFactory;

import dao.TeamDao;
import dao.TeamDaoImpl;
import pojos.Team;
import utils.HibernateUtils;

public class DisplayTeamDetails {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try(SessionFactory SF = HibernateUtils.getSf())
		{
			TeamDao dao = new TeamDaoImpl();
			System.out.println("Display Team Details: ");
			
			List<Team> teamList = dao.displayAllTeamDetails();
			
			for(Team list:teamList)
			{
				System.out.println(list);
			}
			
		}

	}

}
