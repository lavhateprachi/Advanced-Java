package com.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import utils.DBUtils;
import com.pojos.User;

public class UserDaoImpl {
	private Connection connection;
	private PreparedStatement pst1;
	private PreparedStatement pst2;
	private PreparedStatement pst3;
	
	//def ctor
	public UserDaoImpl() throws SQLException, ClassNotFoundException{
		// get cn from db utils
		connection=DBUtils.openConnection();
		pst1=connection.prepareStatement("select first_name,last_name,dob,status from users where role=? and dob between ? and ?");
		pst2=connection.prepareStatement("select * from users where email = ? and password = ?");
		pst3=connection.prepareStatement("select * from users");
		
		System.out.println("user dao created!");
	}

	public List<User> getSelectedUsers(String role, Date begin, Date end) throws SQLException {
		// set IN params
		pst1.setString(1,role);
		pst1.setDate(2, begin);
		pst1.setDate(3, end);
		//exec query : execQuery() --- RST
		List<User> users=new ArrayList<>();
		try(ResultSet rst=pst1.executeQuery())
		{
			while(rst.next())
				users.add(new User(rst.getString(1),rst.getString(2)
						,rst.getDate(3),rst.getBoolean(4)));
		}
		return users;//DAO rets populated list of users to tester.
	}
	public User validateUser(String email,String password) throws SQLException
	{
		pst2.setString(1, email);
		pst2.setString(2, password);
		//List<User> users=new ArrayList<User>();
		try(ResultSet rs = pst2.executeQuery())
		{
			if(rs.next())
			{
				//firstName, lastName, dob,votingStatus, role
				return new User(rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getDate(6),rs.getBoolean(7),rs.getString(8));
			}
		}
		return null;
		
	}
	public List<User> displayAllUsers() throws SQLException {
		// set IN params
		//exec query : execQuery() --- RST
		List<User> users=new ArrayList<>();
		try(ResultSet rs=pst3.executeQuery())
		{
			while(rs.next())
				users.add(new User(rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getDate(6),rs.getBoolean(7),rs.getString(8)));
		}
		return users;//DAO rets populated list of users to tester.
	}
	//clean up 
	public void cleanUp() throws SQLException
	{
		if(pst2 != null)
			pst2.close();
		DBUtils.closeConnection();
		System.out.println("user dao cleaned up !");
	}
	
}
