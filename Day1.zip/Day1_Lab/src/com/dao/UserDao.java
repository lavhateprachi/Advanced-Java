package com.dao;
import java.sql.Date;
import java.util.List;
import com.pojos.*;


public interface UserDao {

	List<User> getUserDetails(String role,Date begin,Date end);
	
	User validateUser(String email,String password);
	
	List<User> displayAllUsers();
}
