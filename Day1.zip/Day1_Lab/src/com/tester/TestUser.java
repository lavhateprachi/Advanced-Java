package com.tester;

import java.sql.Date;
import java.util.List;
import java.util.Scanner;
import com.pojos.*;
import com.dao.UserDaoImpl;

public class TestUser {

		public static void main(String[] args) {
			try (Scanner sc = new Scanner(System.in)) {
				// create dao instance
				UserDaoImpl dao = new UserDaoImpl();
				System.out.println("Enter role begin n end date");
				List<User> user = dao.getSelectedUsers(sc.next(), Date.valueOf(sc.next()), Date.valueOf(sc.next()));
				for(User usersList:user)
				{
					System.out.println(usersList);
				}
				System.out.println("Enter Email and Password : ");
				//tester  --> Dao's method
				User users = dao.validateUser(sc.next(),sc.next());
				System.out.println("Selected Users ");
				System.out.println(users);
				
				System.out.println("Display All Users: ");
				List<User> details = dao.displayAllUsers();
				for(User userData:details)
				{
					System.out.println(details);
				}
				
				System.out.println("!!!!!!");
				//clean up
				dao.cleanUp();

			} 
			catch (Exception e) {
				e.printStackTrace();
			}

		}

}
